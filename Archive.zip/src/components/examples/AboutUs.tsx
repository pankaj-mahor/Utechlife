import AboutUs from '../AboutUs';

export default function AboutUsExample() {
  return <AboutUs />;
}