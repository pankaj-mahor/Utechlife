import ProductPortfolio from '../ProductPortfolio';

export default function ProductPortfolioExample() {
  return <ProductPortfolio />;
}