import Industries from '../Industries';

export default function IndustriesExample() {
  return <Industries />;
}